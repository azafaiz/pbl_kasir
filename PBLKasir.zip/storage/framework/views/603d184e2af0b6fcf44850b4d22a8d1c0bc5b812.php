

<?php $__env->startSection('content'); ?>
    <?php if(Auth::user()->role == 'admin'): ?>
        <div class="row">
            <div class="col-md-12 bg-white">
                <div>
                    <h2 class="mt-3">Tambah Barang</h2>
                </div>
                <div>
                    <a class="btn btn-galang mb-2" href="<?php echo e(route('barang.index')); ?>"> Kembali </a>
                </div>
            </div>
        </div>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('barang.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="row bg-white">
                <div class="col-xs-12 col-sm-12 col-md-12 bg-white">
                    <div class="form-group">
                        <strong>Kode Barang :</strong>
                        <div class="row">
                            <div class="col-md-6"> <input type="text" name="barang_id" class="form-control"
                                    placeholder="kode barang" id="barang_id"></div>
                            <div class="col-md-6"> <input type="button" onclick="Random();"
                                    class="btn btn-galang d-flex justify-content-end" value="GENERATE"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <strong>Nama Barang :</strong>
                        <input type="text" name="nama" class="form-control" placeholder="Nama">

                    </div>
                    <div class="form-group">
                        <strong> Kategori :</strong>
                        <select class="form-control" id="position-option" name="kategori_id">
                            <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->kategori_id); ?>"><?php echo e($item->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    </div>
                    <div class="form-group">
                        <strong> Supplier :</strong>
                        <select class="form-control" id="position-option" name="supplier_id">
                            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->supplier_id); ?>"><?php echo e($item->nama_supplier); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    </div>
                    <div class="form-group">
                        <strong>Harga Beli :</strong>
                        <input type="number" name="harga_beli" class="form-control" placeholder="Harga Beli">

                    </div>
                    <div class="form-group">
                        <strong>Harga Jual :</strong>
                        <input type="number" name="harga_jual" class="form-control" placeholder="Harga Jual">

                    </div>
                    <div class="form-group">
                        <strong>Jumlah Stok</strong>
                        <input type="number" name="stok" class="form-control" placeholder="Stok">

                    </div>

                </div>

                <div class="col-xs-12 col-sm-12 col-md-12 text-center mt-3">
                    <button type="submit" class="btn btn-galang">Simpan</button>
                </div>
            </div>

        </form>
    <?php else: ?>
        <script>
            window.alert("Anda tidak memiliki akses ke halaman ini");
            window.location.href = "/home";
        </script>
    <?php endif; ?>
    <script>
        function Random() {
            // var rnd = Math.floor(Math.random() * 100000);
            var rnd = (Math.random() + 1).toString(36).substring(3);
            document.getElementById('barang_id').value = rnd;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Matkul\Semester 6 (SIB)\PBL_Kasir\PBLKasir\resources\views/barang/create.blade.php ENDPATH**/ ?>