

<?php $__env->startSection('content'); ?>
    <?php if(Auth::user()->role == 'admin'): ?>
        <div class="row">
            <div class="col-sm-12 bg-white">
                <h2 class="mt-2">Daftar Karyawan</h2>


            </div>
            <div class="col bg-white">
                <a class="btn btn-galang mb-3" href="<?php echo e(route('user.create')); ?>"> Tambah Karyawan</a>
            </div>

        </div>

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <?php if($message = Session::get('error')): ?>
            <div class="alert alert-danger">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>

        <table class="table table-bordered bg-white">
            <tr>
                <th style="width: 5%">No</th>
                <th>Nama </th>
                <th>Email</th>

                <th width="280px">Action</th>
            </tr>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e(++$i); ?></th>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->email); ?></td>

                    <td>
                        <form action="<?php echo e(route('user.destroy', $item->id)); ?>" method="POST">

                            <a class="btn btn-galang" href="<?php echo e(route('user.edit', $item->id)); ?>">Edit</a>

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <div class="row d-flex justify-content-center text-center bg-white">
            <?php echo e($user->links()); ?>

        </div>
    <?php else: ?>
        <script>
            window.alert('Anda tidak memiliki akses ke halaman ini');
            window.location = '/home';
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Matkul\Semester 6 (SIB)\PBL_Kasir\PBLKasir\resources\views/user/index.blade.php ENDPATH**/ ?>