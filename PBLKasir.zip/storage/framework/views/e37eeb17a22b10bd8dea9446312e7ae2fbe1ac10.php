

<?php $__env->startSection('content'); ?>
    <?php if(Auth::user()->role == 'admin'): ?>
        <div class="row">
            <div class="col-sm-12 bg-white">
                <h2 class="mt-2">Transaksi</h2>


            </div>

            
        </div>

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <?php
            // dd($history);
        ?>
        <div class="row bg-white">
            <div class="col">
                <form action="/lihathistory" method="GET">
                    <label for="tanggal_mulai">Tanggal Mulai:</label>
                    <input type="date" name="tanggal_mulai" value="<?php echo e(request('tanggal_mulai')); ?>">
                    <label for="tanggal_akhir">Tanggal Akhir:</label>
                    <input type="date" name="tanggal_akhir" value="<?php echo e(request('tanggal_akhir')); ?>">
                    <button type="submit" class="btn btn-galang">Filter</button>
                </form>
            </div>

        </div>


        <table class="table table-bordered m-0 mt-2 bg-white ">
            <tr>
                <th style="width: 5%">No</th>
                
                <th>Nama Barang</th>
                <th>Harga Jual</th>
                <th>Harga Beli</th>
                <th>Quantity</th>
                <th>Total</th>
                <th>Laba</th>
                <th>Waktu Transaksi</th>

                
            </tr>
            <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e(++$i); ?></th>
                    
                    <?php $__currentLoopData = $item['barang']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($barang->nama); ?></td>
                        <td><?php echo e($barang->harga_jual); ?></td>
                        <td><?php echo e($barang->harga_beli); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($item->jumlah); ?></td>
                    <td><?php echo e($item->total); ?></td>
                    <td><?php echo e($item->laba); ?></td>
                    <td><?php echo e($item->updated_at); ?></td>




                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
        <div class="row m-0 mt-1 bg-white">
            <?php
                $totalterjual = 0;
                $totallaba = 0;
                foreach ($history as $item) {
                    $totalterjual += $item->total;
                    $totallaba += $item->laba;
                }
            ?>
            <div class="col-md-3">
                <h5>Total Penjualan: <b>Rp. <?php echo e($totalterjual); ?></b></h5>
            </div>
            <div class="col">
                <h5>Total Laba: <b>Rp. <?php echo e($totallaba); ?></b></h5>


            </div>

        </div>
        
    <?php else: ?>
        <script>
            window.alert("Anda tidak memiliki akses ke halaman ini");
            window.location.href = "/home";
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Matkul\Semester 6 (SIB)\PBL_Kasir\PBLKasir\resources\views/transaksi/history.blade.php ENDPATH**/ ?>