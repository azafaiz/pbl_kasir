<center>
    <h1>Hallo Silahkan verifikasi email</h1>

    <a href="http://127.0.0.1:8000/verifikasi/{{ $email }}">
        <button>Verifikasi</button>
    </a>
</center>
